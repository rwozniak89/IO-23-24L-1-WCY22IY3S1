public class PracownikDziałuReklamacji extends Uzytkownik {

	public void obsluzReklamacje() {

	}

}
