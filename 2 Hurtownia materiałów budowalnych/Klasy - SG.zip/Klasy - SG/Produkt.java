public class Produkt {

	private int ID;

	private string name;

	private Producent producent;

	private float cena;

	public int getID() {
		return 0;
	}

	public string getName() {
		return null;
	}

	public float getCena() {
		return 0;
	}

}
