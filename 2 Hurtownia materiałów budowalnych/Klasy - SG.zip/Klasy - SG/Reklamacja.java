public class Reklamacja {

	private int ID;

	private Klient klient;

	private Zamowienie zamowienie;

	private Produkt produkt;

	private PracownikDziałuReklamacji obslugujacy;

	protected int stan;

	public int getID() {
		return 0;
	}

	protected void setObslugujacy() {

	}

	public int getStan() {
		return 0;
	}

}
