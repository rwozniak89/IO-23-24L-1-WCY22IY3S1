public class Uzytkownik {

	private int ID;

	private string firstName;

	private string lastName;

	public int getID() {
		return 0;
	}

	public string getFirstName() {
		return null;
	}

	public string getLastName() {
		return null;
	}

	public void Uzytkownik(int ID, string firstName, int lastName) {

	}

}
