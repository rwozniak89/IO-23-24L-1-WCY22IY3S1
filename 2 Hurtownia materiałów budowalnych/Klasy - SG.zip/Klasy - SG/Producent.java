public class Producent extends Uzytkownik {

	public void dodajProdukt() {

	}

}
