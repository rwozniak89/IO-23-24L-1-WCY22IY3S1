public class KolejkaReklamacji {

	private Reklamacja reklamacje;

	public void dodajReklamacje() {

	}

	public Reklamacja pobierzReklamacje() {
		return null;
	}

}
