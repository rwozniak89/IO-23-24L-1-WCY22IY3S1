public class Zamowienie {

	private int ID;

	private Klient klient;

	private Produkt produkty;

	public int getID() {
		return 0;
	}

	public Klient getKlient() {
		return null;
	}

	public Produkt getProdukty() {
		return null;
	}

	public float getCena() {
		return 0;
	}

}
