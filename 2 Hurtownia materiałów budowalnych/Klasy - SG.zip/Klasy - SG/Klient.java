public class Klient extends Uzytkownik {

	public void zamow() {

	}

	public void zlozReklamacje(Zamowienie zamowienie, Produkt produkt) {

	}

	public void Klient() {

	}

}
