public class KierownikDzialuReklamacji extends Uzytkownik {

	public void przypiszPracownikaDoReklamacji() {

	}

	public void wysweitlReklamacje() {

	}

}
