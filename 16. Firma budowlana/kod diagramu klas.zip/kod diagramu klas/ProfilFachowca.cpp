#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ProfilFachowca.h"


void ProfilFachowca::dodajOpinie()
{
}

void ProfilFachowca::ocenFachowca()
{
}

void ProfilFachowca::kontaktZFachowcem()
{
}

void ProfilFachowca::wyswietlDostepnoscFachowca()
{
}
