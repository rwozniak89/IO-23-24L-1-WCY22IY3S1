#ifndef UZYTKOWNIK_H
#define UZYTKOWNIK_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Ogloszenie.h"

class Uzytkownik : public Ogloszenie
{
protected:
	int ID;

	string Imie;

	string Nazwisko;

	string adresEmail;


public:
	void zalozKonto(string nazwaUzytkownika, string haslo);

	void zmienHaslo(int noweHaslo);

	void dodajOgloszenie();

	void usunOgloszenie();

	void usunKonto();

};
#endif
