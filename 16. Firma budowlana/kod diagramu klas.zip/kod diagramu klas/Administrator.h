#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"

class Administrator : public Uzytkownik
{
private:
	int poziomUprawnien;

	bool statusDostepnosci;

	int liczbaRozwiazanychZgloszen;


public:
	void usunKonto();

	void przegladajZgloszenia();

	void zamykanieTicketowZInfolinii(int IDTicketu);

	void ogloszeniaGlobalne();

	void wyswietlStatusDostepnosci();

};
#endif
