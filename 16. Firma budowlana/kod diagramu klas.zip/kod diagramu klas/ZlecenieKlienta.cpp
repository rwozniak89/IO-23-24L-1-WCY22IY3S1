#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ZlecenieKlienta.h"


void ZlecenieKlienta::wyswietlanieZdjec()
{
}

string ZlecenieKlienta::bezposredniKontakt()
{
	return 0;
}

void ZlecenieKlienta::wyswietlenieLokalizacji()
{
}

void ZlecenieKlienta::dopytanieOSzczegoly(string trescWiadomosci)
{
}

void ZlecenieKlienta::wyswietlBudzet()
{
}
