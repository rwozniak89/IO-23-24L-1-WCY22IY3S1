#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ZlecenioDawca.h"


ZlecenieKlienta ZlecenioDawca::zalozOgloszenie()
{
	return 0;
}

void ZlecenioDawca::dodajZdjecia()
{
}

void ZlecenioDawca::dodajProjekt()
{
}

void ZlecenioDawca::usunOgloszenie()
{
}

string ZlecenioDawca::wyswietlNick()
{
	return 0;
}
