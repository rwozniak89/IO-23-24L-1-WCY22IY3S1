#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"


void Uzytkownik::zalozKonto(string nazwaUzytkownika, string haslo)
{
}

void Uzytkownik::zmienHaslo(int noweHaslo)
{
}

void Uzytkownik::dodajOgloszenie()
{
}

void Uzytkownik::usunOgloszenie()
{
}

void Uzytkownik::usunKonto()
{
}
