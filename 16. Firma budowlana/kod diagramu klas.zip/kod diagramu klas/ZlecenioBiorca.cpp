#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ZlecenioBiorca.h"


void ZlecenioBiorca::zalozenieProfiluPublicznego()
{
}

void ZlecenioBiorca::modyfikacjaKompetencji()
{
}

void ZlecenioBiorca::przyjmijZlecenie()
{
}

void ZlecenioBiorca::dodajZdjeciaWykonanychZlecen()
{
}

void ZlecenioBiorca::edycjaSwojegoProfilu()
{
}
