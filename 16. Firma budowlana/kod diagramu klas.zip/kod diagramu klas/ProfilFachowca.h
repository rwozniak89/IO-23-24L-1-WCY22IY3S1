#ifndef PROFIL_FACHOWCA_H
#define PROFIL_FACHOWCA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Ogloszenie.h"

class ProfilFachowca : public Ogloszenie
{
private:
	int idFachowca;

	int dataZalozenia;

	int ostatnioOnline;


public:
	void dodajOpinie();

	void ocenFachowca();

	void kontaktZFachowcem();

	void wyswietlDostepnoscFachowca();

};
#endif
