#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Administrator.h"


void Administrator::usunKonto()
{
}

void Administrator::przegladajZgloszenia()
{
}

void Administrator::zamykanieTicketowZInfolinii(int IDTicketu)
{
}

void Administrator::ogloszeniaGlobalne()
{
}

void Administrator::wyswietlStatusDostepnosci()
{
}
