#ifndef OGLOSZENIE_H
#define OGLOSZENIE_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

class Ogloszenie
{
protected:
	int idOgloszenia;

	string autor;

	string data;

	string tytul;

	boolean aktualne;

	string opis;


public:
	void dodajOgloszenie(string tytul, string tresc);

	void usunOgloszenie();

	void modyfikujTytul(string nowyTytul);

	void modyfikujOpis(string nowaTresc);

	void zglosOgloszenie();

};
#endif
