#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Ogloszenie.h"


void Ogloszenie::dodajOgloszenie(string tytul, string tresc)
{
}

void Ogloszenie::usunOgloszenie()
{
}

void Ogloszenie::modyfikujTytul(string nowyTytul)
{
}

void Ogloszenie::modyfikujOpis(string nowaTresc)
{
}

void Ogloszenie::zglosOgloszenie()
{
}
