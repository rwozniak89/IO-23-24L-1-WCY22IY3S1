#ifndef ZLECENIO_DAWCA_H
#define ZLECENIO_DAWCA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"
#include "ZlecenieKlienta.h"

class ZlecenioDawca : public Uzytkownik
{
private:
	string kontakt;

	string adres;

	string nick;


public:
	ZlecenieKlienta zalozOgloszenie();

	void dodajZdjecia();

	void dodajProjekt();

	void usunOgloszenie();

	string wyswietlNick();

};
#endif
