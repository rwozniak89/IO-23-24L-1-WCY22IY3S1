#ifndef ZLECENIE_KLIENTA_H
#define ZLECENIE_KLIENTA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Ogloszenie.h"

class ZlecenieKlienta : public Ogloszenie
{
private:
	string odKiedyMoznaZaczac;

	string lokalizacja;

	string kontakt;

	int budzet;


public:
	void wyswietlanieZdjec();

	string bezposredniKontakt();

	void wyswietlenieLokalizacji();

	void dopytanieOSzczegoly(string trescWiadomosci);

	void wyswietlBudzet();

};
#endif
