#ifndef ZLECENIO_BIORCA_H
#define ZLECENIO_BIORCA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"

class ZlecenioBiorca : public Uzytkownik
{
private:
	int nrTelefonu;

	int czasOdZalozeniaKonta;

	double liczbaWykonanychPrac;


public:
	void zalozenieProfiluPublicznego();

	void modyfikacjaKompetencji();

	void przyjmijZlecenie();

	void dodajZdjeciaWykonanychZlecen();

	void edycjaSwojegoProfilu();

};
#endif
