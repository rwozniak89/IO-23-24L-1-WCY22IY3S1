#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ZamowienieHurtownia.h"


void ZamowienieHurtownia::dodajDoZamowienia(Egzemplarz* produkt, int ilosc)
{
}

void ZamowienieHurtownia::usunZZamowienia(Egzemplarz* produkt)
{
}

void ZamowienieHurtownia::zrealizujZamowienie()
{
}

void ZamowienieHurtownia::anulujZamowienie()
{
}

void ZamowienieHurtownia::zarzadzajPlatnoscia()
{
}

void ZamowienieHurtownia::zapiszZamowienie(Zamawiajacy* zamawiajacy)
{
}
