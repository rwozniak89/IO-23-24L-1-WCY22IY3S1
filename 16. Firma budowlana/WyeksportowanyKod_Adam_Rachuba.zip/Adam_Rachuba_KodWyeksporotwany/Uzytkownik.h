#ifndef UZYTKOWNIK_H
#define UZYTKOWNIK_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

class Uzytkownik
{
private:
	string email;

	string Haslo;


protected:
	int ID;

	string imie;

	string Nazwisko;


protected:
	void zalozKonto(string imie, string nazwisko, string haslo, string email);

	void usunKonto();

	void zmienHaslo(string haslo);

	void zmienDane(string imie, string haslo);

};
#endif
