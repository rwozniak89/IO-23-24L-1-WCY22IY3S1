#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Platnosc.h"


void Platnosc::polaczZBankiem()
{
}

void Platnosc::wykonajPlatnosc()
{
}

void Platnosc::wykonajZwrot()
{
}

void Platnosc::wygenerujFakture(ZamowienieHurtownia* zamowienie)
{
}
