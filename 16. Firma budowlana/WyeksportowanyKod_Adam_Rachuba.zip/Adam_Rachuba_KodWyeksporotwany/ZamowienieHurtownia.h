#ifndef ZAMOWIENIE_HURTOWNIA_H
#define ZAMOWIENIE_HURTOWNIA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Hurtownia.h"
#include "Zamawiajacy.h"
#include "Egzemplarz.h"
#include "Platnosc.h"

class ZamowienieHurtownia
{
private:
	Hurtownia* hurtownia;

	Zamawiajacy* zamawiajacy;

	Egzemplarz* zamowioneTowary[];

	int zamowionaIlosc[];

	Platnosc* platnosc;


protected:
	void zrealizujZamowienie();

	void anulujZamowienie();

	void zarzadzajPlatnoscia();

	void zapiszZamowienie(Zamawiajacy* zamawiajacy);

public:
	void dodajDoZamowienia(Egzemplarz* produkt, int ilosc);

	void usunZZamowienia(Egzemplarz* produkt);

};
#endif
