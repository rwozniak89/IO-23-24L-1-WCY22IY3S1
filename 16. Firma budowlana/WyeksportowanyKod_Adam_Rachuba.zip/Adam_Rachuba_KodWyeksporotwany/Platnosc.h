#ifndef PLATNOSC_H
#define PLATNOSC_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "ZamowienieHurtownia.h"

class Platnosc
{
private:
	string Typ;

	double Wartosc;

	string Realizacja;


private:
	void polaczZBankiem();

	void wykonajPlatnosc();

	void wykonajZwrot();

public:
	void wygenerujFakture(ZamowienieHurtownia* zamowienie);

};
#endif
