#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"


void Uzytkownik::zalozKonto(string imie, string nazwisko, string haslo, string email)
{
}

void Uzytkownik::usunKonto()
{
}

void Uzytkownik::zmienHaslo(string haslo)
{
}

void Uzytkownik::zmienDane(string imie, string haslo)
{
}
