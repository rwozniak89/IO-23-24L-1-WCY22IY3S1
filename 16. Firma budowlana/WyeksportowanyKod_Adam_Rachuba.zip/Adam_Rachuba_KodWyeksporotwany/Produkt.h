#ifndef PRODUKT_H
#define PRODUKT_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Konsultant.h"

class Produkt
{
private:
	string nazwa;

	string typ;

	string opis;

	Konsultant konsultant;

private:
	void aktualizujOpis();

	void zmienOpis();

	void zmienTyp(string typ);

	void zmienNazwe(string nazwa);

};
#endif
