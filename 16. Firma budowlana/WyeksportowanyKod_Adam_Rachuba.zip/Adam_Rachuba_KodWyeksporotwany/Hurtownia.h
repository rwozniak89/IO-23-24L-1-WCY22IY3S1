#ifndef HURTOWNIA_H
#define HURTOWNIA_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Egzemplarz.h"
#include "Konsultant.h"
#include "Produkt.h"

class Hurtownia
{
private:
	string lokalizacja;

	string nazwa;

	string telefon;

	string e-mail;

	Egzemplarz produkty[];

	Konsultant konsultant;

private:
	void usunProdukt(Egzemplarz produkt);

	void dodajProdukt(Produkt* produkt, int ilosc, string jednostki);


protected:
	boolean potwierdzZamowienie();


public:
	void zlozZamowienie(Egzemplarz produkt, int ilosc);

	Egzemplarz* czyProduktDostepny(Egzemplarz produkt);

};
#endif
