#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Hurtownia.h"


void Hurtownia::zlozZamowienie(Egzemplarz produkt, int ilosc)
{
}

Egzemplarz* Hurtownia::czyProduktDostepny(Egzemplarz produkt)
{
	return 0;
}

boolean Hurtownia::potwierdzZamowienie()
{
	return 0;
}

void Hurtownia::usunProdukt(Egzemplarz produkt)
{
}

void Hurtownia::dodajProdukt(Produkt* produkt, int ilosc, string jednostki)
{
}
