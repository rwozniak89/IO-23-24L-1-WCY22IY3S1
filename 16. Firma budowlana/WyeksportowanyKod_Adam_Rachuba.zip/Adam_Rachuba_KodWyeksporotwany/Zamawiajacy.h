#ifndef ZAMAWIAJACY_H
#define ZAMAWIAJACY_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"
#include "ZamowienieHurtownia.h"

class Zamawiajacy : public Uzytkownik
{
private:
	boolean czyFirma;

	string NIP;

	string adres;

	string telefon;


public:
	void zamow(ZamowienieHurtownia* zamowienie);

	void zrezygnuj(ZamowienieHurtownia* zamowienie);

	void modyfikujDane(boolean czyFirma, string NIP, string adres, string telegon);

	void pokazHistorieZamowien();

};
#endif
