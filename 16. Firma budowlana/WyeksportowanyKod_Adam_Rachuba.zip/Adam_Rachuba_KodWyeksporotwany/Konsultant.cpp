#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Konsultant.h"


void Konsultant::dodajProdukt(string nazwa, string typ, string opis)
{
}

void Konsultant::modyfikujProdukt(Produkt* produkt, string nazwa, string typ, string opis)
{
}

void Konsultant::usunProdukt(Produkt* produkt)
{
}

void Konsultant::dodajDoHurtowni(Produkt* produkt, string cena, int ilosc, string jednostki)
{
}

void Konsultant::modyfikujWHurtowni(Produkt* produkt, string cena, int ilosc, string jednostki)
{
}

void Konsultant::usunZHurtowni(Produkt* produkt)
{
}
