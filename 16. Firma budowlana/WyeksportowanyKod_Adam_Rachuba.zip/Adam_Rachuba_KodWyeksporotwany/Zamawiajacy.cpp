#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Zamawiajacy.h"


void Zamawiajacy::zamow(ZamowienieHurtownia* zamowienie)
{
}

void Zamawiajacy::zrezygnuj(ZamowienieHurtownia* zamowienie)
{
}

void Zamawiajacy::modyfikujDane(boolean czyFirma, string NIP, string adres, string telegon)
{
}

void Zamawiajacy::pokazHistorieZamowien()
{
}
