#ifndef EGZEMPLARZ_H
#define EGZEMPLARZ_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Produkt.h"
#include "Hurtownia.h"

class Egzemplarz
{
private:
	Produkt* produkt;

	string cenaZaJednostke;

	int ilosc;

	string jednostki;

	Hurtownia hurtownia;

private:
	int dodajIlosc(int ilosc);

	int zmniejszIlosc(int ilosc);

	void modyfikujCene(string cena);

	void modyfikujJednostke(string jednostka);

public:
	int zwrocIlosc();

};
#endif
