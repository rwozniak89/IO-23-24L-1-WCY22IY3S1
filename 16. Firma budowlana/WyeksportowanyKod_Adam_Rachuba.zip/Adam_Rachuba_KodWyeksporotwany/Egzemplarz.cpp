#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Egzemplarz.h"


int Egzemplarz::zwrocIlosc()
{
	return 0;
}

int Egzemplarz::dodajIlosc(int ilosc)
{
	return 0;
}

int Egzemplarz::zmniejszIlosc(int ilosc)
{
	return 0;
}

void Egzemplarz::modyfikujCene(string cena)
{
}

void Egzemplarz::modyfikujJednostke(string jednostka)
{
}
