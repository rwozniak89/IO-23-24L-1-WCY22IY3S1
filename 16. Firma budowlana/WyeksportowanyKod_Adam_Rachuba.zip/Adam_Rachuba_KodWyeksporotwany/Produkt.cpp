#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Produkt.h"


void Produkt::aktualizujOpis()
{
}

void Produkt::zmienOpis()
{
}

void Produkt::zmienTyp(string typ)
{
}

void Produkt::zmienNazwe(string nazwa)
{
}
