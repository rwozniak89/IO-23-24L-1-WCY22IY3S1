#ifndef KONSULTANT_H
#define KONSULTANT_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Uzytkownik.h"
#include "Hurtownia.h"
#include "Produkt.h"

class Konsultant : public Uzytkownik
{
private:
	int poziomUprawnien;

	int telefon;

	Hurtownia* hurtownia[];


private:
	void dodajProdukt(string nazwa, string typ, string opis);

	void modyfikujProdukt(Produkt* produkt, string nazwa, string typ, string opis);

	void usunProdukt(Produkt* produkt);

	void dodajDoHurtowni(Produkt* produkt, string cena, int ilosc, string jednostki);

	void modyfikujWHurtowni(Produkt* produkt, string cena, int ilosc, string jednostki);

	void usunZHurtowni(Produkt* produkt);

};
#endif
